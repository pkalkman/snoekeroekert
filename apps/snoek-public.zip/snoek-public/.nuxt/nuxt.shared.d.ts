/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
