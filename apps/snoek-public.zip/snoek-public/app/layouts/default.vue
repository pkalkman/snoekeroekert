<template>
  <div class="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex flex-col">
    <LayoutHeader />
    <div class="flex flex-grow ">
      <slot />
    </div>
  </div>
</template>
