<template>
  <div class=" w-full bg-gray-900 overflow-hidden">
    <!-- Professional Floating Navigation -->


    <!-- Professional Hero Section -->
    <section class="relative flex items-center justify-center">
      <!-- Random Starfield - Multiple sizes and positions -->
      <div class="absolute inset-0">
        <!-- Large Stars -->
        <div class="absolute top-24 left-20 w-7 h-7 text-yellow-300 opacity-45 animate-spin-subtle">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <div class="absolute bottom-32 right-24 w-6 h-6 text-yellow-300 opacity-40 animate-pulse-subtle">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <!-- Medium Stars -->
        <div class="absolute top-40 right-32 w-5 h-5 text-yellow-300 opacity-35 animate-twinkle">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <div class="absolute top-1/2 left-12 w-4 h-4 text-yellow-300 opacity-30 animate-twinkle-slow">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <div class="absolute bottom-1/3 left-1/3 w-5 h-5 text-yellow-300 opacity-38 animate-pulse-gentle">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <div class="absolute top-1/4 left-2/3 w-4 h-4 text-yellow-300 opacity-42 animate-twinkle-fast">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <!-- Small Stars -->
        <div class="absolute top-16 right-1/4 w-3 h-3 text-yellow-300 opacity-25 animate-twinkle-slow">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <div class="absolute bottom-16 left-1/5 w-3 h-3 text-yellow-300 opacity-28 animate-pulse-gentle">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <div class="absolute top-3/4 right-1/5 w-2 h-2 text-yellow-300 opacity-22 animate-twinkle">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <div class="absolute top-1/3 right-1/6 w-3 h-3 text-yellow-300 opacity-32 animate-spin-subtle-slow">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <!-- Tiny Stars -->
        <div class="absolute top-12 left-1/3 w-2 h-2 text-yellow-300 opacity-20 animate-twinkle-fast">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <div class="absolute bottom-12 right-1/3 w-2 h-2 text-yellow-300 opacity-26 animate-pulse-subtle">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <div class="absolute top-2/3 left-1/6 w-2 h-2 text-yellow-300 opacity-24 animate-twinkle-slow">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <div class="absolute top-1/6 right-2/5 w-2 h-2 text-yellow-300 opacity-18 animate-pulse-gentle">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <div class="absolute bottom-1/6 left-2/5 w-2 h-2 text-yellow-300 opacity-21 animate-twinkle">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <!-- Extra scattered tiny stars -->
        <div class="absolute top-1/5 left-3/4 w-1.5 h-1.5 text-yellow-300 opacity-15 animate-twinkle-fast">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        
        <div class="absolute bottom-1/5 right-3/4 w-1.5 h-1.5 text-yellow-300 opacity-17 animate-pulse-subtle">
          <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
      </div>

      <!-- Professional Content -->
      <div class="relative z-10 max-w-7xl mx-auto px-6 text-center">
        <!-- Company Badge -->
        <div class="inline-flex items-center px-6 py-3 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full text-white/80 text-sm font-medium mb-8 hover:bg-white/10 transition-all duration-300">
          <span class="w-2 h-2 bg-emerald-100 rounded-full mr-3 animate-pulse-gentle"></span>
          Trusted by Fortune 500 Companies
        </div>

        <!-- Main Headline -->
        <div class="mb-8">
          <h1 class="inline-block bg-gradient-to-r from-lime-200 via-green-200 to-emerald-100 text-transparent bg-clip-text text-7xl md:text-8xl lg:text-9xl font-black tracking-tight leading-none">
            ENTERPRISE
          </h1>
          <div class="mt-4">
            <span class="inline-block bg-gradient-to-r from-teal-100 via-emerald-100 to-green-200 text-transparent bg-clip-text text-4xl md:text-5xl lg:text-6xl font-bold tracking-wide">
              SOLUTIONS
            </span>
          </div>
        </div>

        <!-- Professional Subtitle -->
        <div class="mb-12 max-w-4xl mx-auto">
          <h2 class="text-white text-xl md:text-3xl font-light mb-6 leading-relaxed">
            Accelerate Digital Transformation with
            <span class="bg-teal-100 text-gray-900 px-4 py-2 rounded-lg font-semibold mx-2 inline-block">AI-Powered Innovation</span>
          </h2>
          <p class="text-gray-300 text-lg md:text-xl leading-relaxed max-w-3xl mx-auto">
            Empower your organization with cutting-edge technology solutions designed for scale, security, and performance. 
            Join industry leaders who trust our platform to drive measurable business outcomes.
          </p>
        </div>
        
        <!-- Professional CTA Section -->
        <div class="flex flex-col lg:flex-row gap-6 justify-center items-center mb-12">
          <button class="group relative bg-gradient-to-r from-green-200 to-lime-200 text-gray-900 px-12 py-5 rounded-xl font-bold text-lg hover:scale-105 transition-all duration-300 shadow-2xl hover:shadow-3xl min-w-[240px]">
            <span class="relative z-10 flex items-center justify-center">
              Start Free Trial
              <svg class="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"></path>
              </svg>
            </span>
            <div class="absolute inset-0 bg-gradient-to-r from-emerald-100 to-teal-100 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </button>
          <button class="border-2 border-emerald-100/50 text-emerald-100 px-12 py-5 rounded-xl font-bold text-lg hover:bg-emerald-100/10 hover:border-emerald-100 transition-all duration-300 min-w-[240px] backdrop-blur-sm">
            Schedule Demo
          </button>
        </div>

        <!-- Trust Indicators -->
        <div class="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-12 text-white/60 text-sm">
          <div class="flex items-center space-x-2">
            <div class="w-3 h-3 bg-green-200 rounded-full"></div>
            <span>SOC 2 Type II Certified</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-3 h-3 bg-emerald-100 rounded-full"></div>
            <span>99.9% SLA Guarantee</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-3 h-3 bg-lime-200 rounded-full"></div>
            <span>24/7 Enterprise Support</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-3 h-3 bg-teal-100 rounded-full"></div>
            <span>Global Infrastructure</span>
          </div>
        </div>
      </div>

      <!-- Subtle Grid Overlay -->
      <div class="absolute inset-0 opacity-3">
        <div class="w-full h-full" style="background-image: radial-gradient(circle, #ffffff 1px, transparent 1px); background-size: 50px 50px;"></div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { useSeoMeta } from '#app';

useSeoMeta({
  title: 'Enterprise Solutions - AI-Powered Digital Transformation',
  description: 'Accelerate your digital transformation with enterprise-grade AI solutions. Trusted by Fortune 500 companies worldwide.',
  keywords: 'enterprise software, digital transformation, AI solutions, business automation',
});
</script>

<style scoped>
/* Varied star animations with different speeds */
@keyframes spin-subtle {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@keyframes spin-subtle-slow {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@keyframes pulse-subtle {
  0%, 100% { opacity: 0.4; }
  50% { opacity: 0.7; }
}

@keyframes pulse-gentle {
  0%, 100% { opacity: 0.6; }
  50% { opacity: 1; }
}

@keyframes twinkle {
  0%, 100% { opacity: 0.3; transform: scale(1); }
  50% { opacity: 0.8; transform: scale(1.2); }
}

@keyframes twinkle-slow {
  0%, 100% { opacity: 0.25; transform: scale(1); }
  50% { opacity: 0.6; transform: scale(1.1); }
}

@keyframes twinkle-fast {
  0%, 100% { opacity: 0.2; transform: scale(1); }
  50% { opacity: 0.7; transform: scale(1.3); }
}

/* Apply varied animations with different durations */
.animate-spin-subtle { 
  animation: spin-subtle 45s linear infinite; 
}

.animate-spin-subtle-slow { 
  animation: spin-subtle-slow 60s linear infinite; 
}

.animate-pulse-subtle { 
  animation: pulse-subtle 5s ease-in-out infinite; 
}

.animate-pulse-gentle { 
  animation: pulse-gentle 3s ease-in-out infinite; 
}

.animate-twinkle { 
  animation: twinkle 3s ease-in-out infinite; 
}

.animate-twinkle-slow { 
  animation: twinkle-slow 7s ease-in-out infinite; 
}

.animate-twinkle-fast { 
  animation: twinkle-fast 2s ease-in-out infinite; 
}

/* Professional shadow utilities */
.shadow-3xl {
  box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.25);
}
</style>